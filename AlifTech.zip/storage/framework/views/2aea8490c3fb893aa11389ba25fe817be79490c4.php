

<?php $__env->startSection('style'); ?>
    <style>
        #img{
            border-radius: 50%;
            width: 50%;
            margin-top: -25%;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div  class="col-md-7  mx-auto">
            <div style="margin-top: 180px"  class="card  shadow">
                <img id="img" src="<?php echo e(asset('storage')); ?>/<?php echo e($contact->image->name ?? 'images/noimage.png'); ?>" alt="">

                <div class="card-body">

                    <form action="<?php echo e(route('image.update',[$contact->id])); ?>" class="mb-3" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($contact->id); ?>">
                        <?php echo method_field('PUT'); ?>
                        <div class="input-group" >
                            <input name="image" placeholder="Image" type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <button class="btn btn-primary " >Update</button>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </form>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card-title">
                                <h5 >
                                    <?php echo e($contact->name); ?>

                                </h5>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <form action="<?php echo e(route('contact.update',[$contact])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="input-group">
                                    <input name="name" placeholder="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <button class="btn btn-primary " >Update</button>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="small ">Phone numbers</h5>
                            <form action="<?php echo e(route('number.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($contact->id); ?>">
                                <div class="input-group ">
                                    <input value="<?php echo e(old('number')); ?>" name="number" type="text" placeholder="** *** ** **" class="d-block form-control <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <button class="input-group-text bg-primary text-white" >Add</button>
                                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </form>
                            <?php $__currentLoopData = $contact->numbers()->where('active',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="small mb-1">
                                    <a onclick="deleteNumber(<?php echo e($phone->id); ?>)" class="badge btn bg-danger" >delete</a> <?php echo e($phone->name); ?>


                                    <form id="number<?php echo e($phone->id); ?>" class="d-none" action="<?php echo e(route('number.destroy',[$phone])); ?>" method="post" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <div class="col-md-6">
                            <h5 class="small">Emails</h5>
                            <form  action="<?php echo e(route('email.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($contact->id); ?>">
                                <div class="input-group ">
                                    <input value="<?php echo e(old('email')); ?>" name="email" type="email" placeholder="email" class="d-block form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <button class="input-group-text bg-primary text-white" >Add</button>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </form>
                            <?php $__currentLoopData = $contact->emails()->where('active',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="small mb-1">
                                    <a onclick="deleteEmail(<?php echo e($email->id); ?>)" class="badge btn bg-danger " >delete</a>  <?php echo e($email->name); ?>

                                    <form id="email<?php echo e($email->id); ?>" class="d-none" action="<?php echo e(route('email.destroy',[$email])); ?>" method="post" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function deleteEmail(id)
        {
            console.log(id);
            document.getElementById('email'+id).submit();
        }
        function deleteNumber(id)
        {
            console.log(id)
            document.getElementById('number'+id).submit();
        }

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/AlifTech/resources/views/contact/show.blade.php ENDPATH**/ ?>