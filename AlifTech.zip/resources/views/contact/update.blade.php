@extends('layout.app')

@section('content')
    <div class="container">
        <h1>Hello</h1>
    </div>
@endsection
